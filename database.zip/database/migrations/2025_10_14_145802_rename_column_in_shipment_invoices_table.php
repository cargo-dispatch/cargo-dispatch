<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('shipment_invoices', function (Blueprint $table) {
            $table->renameColumn('toatl_with_profit', 'total_with_profit');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('shipment_invoices', function (Blueprint $table) {
             $table->renameColumn('total_with_profit', 'toatl_with_profit');
        });
    }
};
